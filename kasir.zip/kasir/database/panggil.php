<?php
include "config/koneksi.php";
include "config/proses.php";

$dbConnect = new koneksi();
$db =$dbConnect->DBConnect();
$proses = new proses($db);

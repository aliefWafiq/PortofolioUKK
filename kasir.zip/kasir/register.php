<?php
include "layout/mainLayout.php";
include "database/panggil.php";
?>
<div class="container d-flex justify-content-center align-items-center" style="height: 100vh;">
  <form action="default.php?menu=register&source=register" method="POST" class="card" style="width: 18rem;">
    <div class="card-body d-flex flex-column">
      <div class="card-title mb-3">
        <h3>Register Form</h3>
      </div>
      <div class="mb-3">
        <label for="username" class="form-label">Username</label>
        <input type="text" class="form-control" id="username" name="username" placeholder="username">
      </div>
      <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" class="form-control" id="password" name="password" placeholder="password">
      </div>
      <select style="display: none;" name="role" id="role" class="form-select" aria-label="Disabled select example" disabled>
        <option value="Petugas" selected>Petugas</option>
      </select>
      <button type="submit" class="btn btn-primary">Submit</button>
      <a href="login.php" class="mt-2">Sudah punya akun?</a>
    </div>
  </form>
</div>
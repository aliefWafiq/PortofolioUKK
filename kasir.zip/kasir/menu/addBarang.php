<?php
if ($_SERVER['REQUEST_METHOD'] == "POST") {
  $namaBarang = strip_tags($_POST['namaBarang']);
  $hargaBarang = strip_tags($_POST['hargaBarang']);
  $stokBarang = strip_tags($_POST['stokBarang']);

  $sql = "INSERT INTO `barang` (`namaBarang`, `hargaBarang`, `stokBarang`) VALUES ('$namaBarang', '$hargaBarang', '$stokBarang')";
  $proses->execute_data($sql);

  return header("location: index.php?pages=listBarang&status=sukses");
}
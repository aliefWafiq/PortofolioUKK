<?php
$id = isset($_GET['id']) ? $_GET['id'] : "";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
  $username = strip_tags($_POST['username']);
  $role = strip_tags($_POST['role']);

  $sql = "UPDATE `user` SET `username` = '$username', `role` = '$role' WHERE `id` = '$id'";
  $proses->execute_data($sql);

  return header("location: index.php?pages=listUser&status=sukses");
}
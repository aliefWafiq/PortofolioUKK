<?php
$source = isset($_GET['source']) ? $_GET['source'] : "";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $username = strip_tags($_POST['username']);
    $password = strip_tags($_POST['password']);
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $role = $_POST['role'] !== null ? $_POST['role'] : "Petugas";

    $check = "SELECT * FROM user WHERE username = '$username'";
    $res = $proses->show_data($check);

    if ($res) {
        if ($source == "register") {
            return header("location: login.php?Username-Sudah-Terdaftar");
        } else {
            return header("location: index.php?pages=listUser&action=add&Username-Sudah-Terdaftar");
        }
    } else {
        $sql = "INSERT INTO `user` (`username`, `password`, `role`) VALUES ('$username', '$hash', '$role')";
        $proses->execute_data($sql);
        if ($source == "register") {
            return header("location: login.php");
        } else {
            return header("location: index.php?pages=listUser&action=add");
        }
    }
}

<?php
$id = isset($_GET['id']) ? $_GET['id'] : "";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
  $totalHarga = strip_tags($_POST['totalHarga']);
  $tanggalTransaksi = strip_tags($_POST['tanggalTransaksi']);

  $sql = "UPDATE `transaksi` SET `totalHarga` = '$totalHarga', `tanggalTransaksi` = '$tanggalTransaksi' WHERE `id` = '$id'";
  $proses->execute_data($sql);

  return header("location: index.php?pages=listTransaksi&status=sukses");
}
<?php
$id = isset($_GET['id']) ? $_GET['id'] : "";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
  $namaBarang = strip_tags($_POST['namaBarang']);
  $hargaBarang = strip_tags($_POST['hargaBarang']);
  $stokBarang = strip_tags($_POST['stokBarang']);

  $sql = "UPDATE `barang` SET `namaBarang` = '$namaBarang', `hargaBarang` = '$hargaBarang', `stokBarang` = '$stokBarang' WHERE `id` = '$id'";
  $proses->execute_data($sql);

  return header("location: index.php?pages=listBarang&status=sukses");
}
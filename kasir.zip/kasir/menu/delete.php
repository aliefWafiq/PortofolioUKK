<?php
$id = isset($_GET['id']) ? $_GET['id'] : "";
$type = isset($_GET['type']) ? $_GET['type'] : "";

if($type == "barang"){
    $sql = "DELETE FROM barang WHERE id = '$id'";
    $proses->execute_data($sql);
    header("location: index.php?pages=listBarang&action=add");
}else if($type == "user"){
    $sql = "DELETE FROM user WHERE id = '$id'";
    $proses->execute_data($sql);
    header("location: index.php?pages=listUser&action=add");
}else if($type == "transaksi"){
    $sql = "DELETE FROM transaksi WHERE id = '$id'";
    $proses->execute_data($sql);
    header("location: index.php?pages=listTransaksi");
}
<?php

class proses{
    
    protected $db;

    public function __construct($db){
        $this->db = $db;
    }

    public function list_data($sql){
        $row = $this->db->prepare($sql);
        $row->execute();
        return $row->fetchAll();
    }

    public function show_data($sql){
        $row = $this->db->prepare($sql);
        $row->execute();
        return $row->fetch();
    }

    public function execute_data($sql){
        $row = $this->db->prepare($sql);
        return $row->execute();
    }

    public function last_inserted_id(){
        return $this->db->lastInsertId();
    }
}
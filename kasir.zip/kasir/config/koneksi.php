<?php
class koneksi{
    public function DBConnect(){
        $host = "localhost";
        $dbname = "kasir";
        $username = "root";
        $password = "";

        try{
            $dbConnect = new PDO("mysql:host=".$host.";dbname=".$dbname."", $username, $password);
            $dbConnect->exec("set names utf8");
            $dbConnect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $dbConnect;
        }catch(PDOException $e){
            echo "Eror: " . $e->getMessage();
        }
 }
}                                     
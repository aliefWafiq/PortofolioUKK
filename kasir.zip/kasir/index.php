<?php
include "database/panggil.php";
include "layout/mainLayout.php";

if(empty($_SESSION['role'])){
    header("location: login.php?logindulu");
}

if($_SESSION['role'] == "Admin"){
    include "components/adminSidebar.php";
}else if($_SESSION['role'] == "Petugas"){
    include "components/petugasSidebar.php";
}

$pages = isset($_GET['pages']) ? $_GET['pages'] : "menu";

if($pages == "dashboard"){
    include 'pages/dashboard.php';
}else if($pages == "menu"){
    include 'pages/menu.php';
}else if($pages == "listBarang"){
    include 'pages/listBarang.php';
}else if($pages == "listUser"){
    include 'pages/listUser.php';
}else if($pages == "listTransaksi"){
    include 'pages/listTransaksi.php';
}
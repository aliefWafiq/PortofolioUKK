<?php
include "layout/mainLayout.php";
include "database/panggil.php";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $username = strip_tags($_POST['username']);
    $password = strip_tags($_POST['password']);

    $sql = "SELECT * FROM `user` WHERE `username` = '$username'";
    $res = $proses->show_data($sql);

    if($res){
        if (password_verify($password, $res['password'])) {
            if ($res['role'] == "Admin") {
                $_SESSION["role"] = "Admin";
                $_SESSION["username"] = $res['username'];
                header("location: index.php?pages=dashboard");
            }else {
                $_SESSION["role"] = "Petugas";
                $_SESSION["username"] = $res['username'];
                header("location: index.php?pages=menu");
            }
        }
    }else{
        header("location: login.php?Username-Atau-Password-Salah");
    }
}
?>

<div class="container d-flex justify-content-center align-items-center" style="height: 100vh;">
    <form method="POST" class="card" style="width: 18rem;">
        <div class="card-body d-flex flex-column">
            <div class="card-title mb-3">
                <h3>Login Form</h3>
            </div>
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" name="username" placeholder="username">
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="password">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
            <a href="register.php" class="mt-2">Belum punya akun?</a>
        </div>
    </form>
</div>
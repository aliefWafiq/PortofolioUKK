<?php
include "database/panggil.php";
include "layout/mainLayout.php";

if($_SESSION['role'] == "Admin"){
    include "components/adminSidebar.php";
}else if($_SESSION['role'] == "Petugas"){
    include "components/petugasSidebar.php";
}

$menu = isset($_GET['menu']) ? $_GET['menu'] : "";

if($menu == "add"){
    include 'menu/addBarang.php';
}else if($menu == "edit"){
    include 'menu/editBarang.php';
}else if($menu == "delete"){
    include 'menu/delete.php';
}else if($menu == "register"){
    include 'menu/register.php';
}else if($menu == "editUser"){
    include 'menu/editUser.php';
}else if($menu == "editTransaksi"){
    include 'menu/editTransaksi.php';
}
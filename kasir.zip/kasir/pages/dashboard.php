<?php
$sqlUser = "SELECT COUNT(*) as total FROM user";
$resUser = $proses->show_data($sqlUser);

$sqlTransaksi = "SELECT COUNT(*) as total FROM transaksi";
$resTransaksi = $proses->show_data($sqlTransaksi);

$sqlTotal = "SELECT SUM(totalHarga) as total FROM transaksi";
$total = $proses->show_data($sqlTotal);

$sql = "SELECT * FROM transaksi LIMIT 10";
$res = $proses->list_data($sql);
?>
<div class="container px-5 py-5">
    <div class="d-flex">
        <div class="card card-outline card-primary col-3 py-3">
            <div class="d-flex">
                <h3><i class="fa-solid fa-user"></i></h3>
                <h3 class="mx-2">User</h3>
            </div>
            <h2 class="mx-2"><?php echo $resUser['total'] ?></h2>
        </div>
        <div class="card card-outline card-primary col-3 py-3 mx-3">
            <div class="d-flex">
                <h3><i class="fa-solid fa-clipboard-list"></i></h3>
                <h3 class="mx-2">Transaksi</h3>
            </div>
            <h2 class="mx-2"><?php echo $resTransaksi['total']; ?></h2>
        </div>
        <div class="card card-outline card-primary col-3 py-3 mx-3">
            <div class="d-flex">
                <h3><i class="fa-solid fa-money-bills"></i></h3>
                <h3 class="mx-2">Total</h3>
            </div>
            <h2 class="mx-2"><?php echo $total['total']; ?></h2>
        </div>
    </div>
    <div class="mt-4">
        <h1>List Transaksi</h1>
        <div class="d-flex">
            <table class="table1 col-12">
                <tr>
                    <th>id</th>
                    <th>Total Harga</th>
                    <th>Tanggal Transaksi</th>
                </tr>
                <?php if (empty($res)) { ?>
                    <td></td>
                    <td>Data Kosong</td>
                    <td></td>
                <?php } ?>
                <?php foreach ($res as $e) { ?>
                    <tr>
                        <td><?php echo $e['id'] ?></td>
                        <td><?php echo $e['totalHarga'] ?></td>
                        <td><?php echo $e['tanggalTransaksi'] ?></td>
                    </tr>
                <?php } ?>
            </table>
        </div>
    </div>
</div>
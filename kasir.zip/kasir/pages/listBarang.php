<?php
$sql = "SELECT * FROM barang";
$res = $proses->list_data($sql);

$action = isset($_GET['action']) ? $_GET['action'] : "add";
?>
<div class="container px-5 py-5">
    <h1>List Barang</h1>
    <div class="d-flex">
        <table class="table1 col-10">
            <tr>
                <th>Nama Barang</th>
                <th>Harga Barang</th>
                <th>Stok Barang</th>
                <th>Action</th>
            </tr>
            <?php if(empty($res)){?>
                <td></td>
                <td>Data Kosong</td>
                <td></td>
                <td></td>
            <?php } ?>
            <?php foreach ($res as $e) { ?>
                <tr>
                    <td><?php echo $e['namaBarang'] ?></td>
                    <td><?php echo $e['hargaBarang'] ?></td>
                    <td><?php echo $e['stokBarang'] ?></td>
                    <td class="d-flex justify-content-center">
                        <a class="btn btn-warning" href="index.php?pages=listBarang&type=barang&action=edit&id=<?php echo $e['id'] ?>">Edit</a>
                        <a class="btn btn-danger mx-3" href="default.php?menu=delete&type=barang&id=<?php echo $e['id'] ?>">Delete</a>
                    </td>
                </tr>
            <?php } ?>
        </table>
        <?php 
        if($action == "edit"){
            include "components/editBarang.php";
        }else{
            include "components/addBarang.php";
        }
        ?>
    </div>
</div>
<?php
$sql = "SELECT * FROM user";
$res = $proses->list_data($sql);

$action = isset($_GET['action']) ? $_GET['action'] : "add";
?>
<div class="container px-5 py-5">
    <h1>List User</h1>
    <div class="d-flex">
        <table class="table1 col-10">
            <tr>
                <th>Username</th>
                <th>Role</th>
                <th>Action</th>
            </tr>
            <?php if(empty($res)){?>
                <td></td>
                <td>Data Kosong</td>
                <td></td>
            <?php } ?>
            <?php foreach ($res as $e) { ?>
                <tr>
                    <td><?php echo $e['username'] ?></td>
                    <td><?php echo $e['role'] ?></td>
                    <td class="d-flex justify-content-center">
                        <a class="btn btn-warning" href="index.php?pages=listUser&type=user&action=edit&id=<?php echo $e['id'] ?>">Edit</a>
                        <a class="btn btn-danger mx-3" href="default.php?menu=delete&type=user&id=<?php echo $e['id'] ?>">Delete</a>
                    </td>
                </tr>
            <?php } ?>
        </table>
        <?php 
        if($action == "edit"){
            include "components/editUser.php";
        }else{
            include "components/addUser.php";
        }
        ?>
    </div>
</div>
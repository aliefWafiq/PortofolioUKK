<?php
$sql = "SELECT * FROM barang";
$res = $proses->list_data($sql);

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $qty = $_POST['qty'];
    $tanggal = date('Y-m-d');

    $insertTransaksi = "INSERT INTO `transaksi` (`totalHarga`, `tanggalTransaksi`) VALUES (0, '$tanggal')";
    $proses->execute_data($insertTransaksi);

    $lastId = $proses->last_inserted_id();

    $totalHarga = 0;
    $itemValid = 0;

    foreach ($qty as $id => $jumlah) {
        $id = (int)$id;
        $jumlah = (int)$jumlah;

        if ($jumlah > 0) {
            $check = 'SELECT * FROM `barang` WHERE id = ' . $id . '';
            $data = $proses->show_data($check);

            if ($data) {
                $harga = $data['hargaBarang'];
                $subtotal = $jumlah * $harga;
                $totalHarga += $subtotal;

                $insertDetail = 'INSERT INTO `detailtransaksi` (`idBarang`, `hargaBarang`, `kuantitas`, `idTransaksi`) 
                VALUES (' . $id . ', ' . $harga . ', ' . $jumlah . ', ' . $lastId . ')';
                $proses->execute_data($insertDetail);

                $stok = $data['stokBarang'] - $jumlah;
                $updateStok = "UPDATE `barang` SET `stokBarang` = '$stok' WHERE `id` = '$id'";
                $proses->execute_data($updateStok);

                $itemValid++;
            }
        }
    }
    if ($itemValid > 0) {
        $update = "UPDATE `transaksi` SET `totalHarga` = '$totalHarga' WHERE `id` = '$lastId'";
        $proses->execute_data($update);
        header('location: index.php?pages=menu');
        echo $update;
        echo $totalHarga;
    }
}
?>
<form method="POST" class="p-5 py-5 d-flex d-flex justify-content-end">
    <div class="d-flex flex-wrap col-7">
        <?php foreach ($res as $e) { ?>
            <div class="card mx-2" style="width: 14rem;">
                <div class="card-body d-flex flex-column">
                    <h2 class="card-title" style="font-weight: 700;"><?php echo $e['namaBarang'] ?></h2>
                    <div class="mt-3">
                        <span>Rp. <?php echo $e['hargaBarang'] ?></span>
                        <p class="mt-2">Stok <?php echo $e['stokBarang'] ?></p>
                    </div>
                    <?php if ($e['stokBarang'] <= 0) { ?>
                        <p class="bg-danger p-2 card">Stok Habis</p>
                    <?php } else { ?>
                        <input
                            type="number"
                            class="form-control input-qty"
                            name="qty[<?php echo $e['id'] ?>]"
                            placeholder="Stok Barang"
                            min="0"
                            value="0"
                            data-nama="<?php echo $e['namaBarang'] ?>"
                            data-harga="<?php echo $e['hargaBarang'] ?>"
                            oninput="renderStruk()">
                    <?php } ?>
                </div>
            </div>
        <?php } ?>
    </div>
    <div class="col-3 card">
        <div class="card-body d-flex flex-column">
            <h2 class="card-title" style="font-weight: 700;">Detail</h2>
            <div class="mt-3">
                <ul id="list"></ul>
            </div>
            <h4>Total: Rp.<span id="totalHarga"><span></h2>
                        <button type="submit" class="btn btn-primary">Beli</button>
        </div>
    </div>
</form>
<script>
    function renderStruk() {
        let inputs = document.querySelectorAll(".input-qty")
        let listHtml = ""
        let totalHarga = 0

        inputs.forEach(input => {
            let qty = parseInt(input.value)

            let nama = input.getAttribute("data-nama")
            let harga = parseInt(input.getAttribute("data-harga"))
            let subtotal = qty * harga

            totalHarga += subtotal

            if (qty > 0) {
                listHtml += `<li>${nama} - ${qty} = Rp.${subtotal.toLocaleString('id-ID')}</li>`
            }
        })
        document.getElementById('list').innerHTML = listHtml
        document.getElementById('totalHarga').innerText = totalHarga.toLocaleString('id-ID')
    }
</script>
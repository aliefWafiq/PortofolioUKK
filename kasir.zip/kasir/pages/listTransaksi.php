<?php
$sql = "SELECT * FROM transaksi";
$res = $proses->list_data($sql);

$action = isset($_GET['action']) ? $_GET['action'] : "";
?>
<div class="container px-5 py-5">
    <div class="d-flex align-items-center">
        <h1>List Barang</h1>
        <button class="btn btn-primary mx-4" onclick="window.print()" style="height: 40px;">Print Transaksi</button>
    </div>
    <div class="d-flex">
        <table class="table1 col-10">
            <tr>
                <th>id</th>
                <th>Total Harga</th>
                <th>Tanggal Transaksi</th>
                <th>Action</th>
            </tr>
            <?php if (empty($res)) { ?>
                <td></td>
                <td>Data Kosong</td>
                <td></td>
                <td></td>
            <?php } ?>
            <?php foreach ($res as $e) { ?>
                <tr>
                    <td><?php echo $e['id'] ?></td>
                    <td><?php echo $e['totalHarga'] ?></td>
                    <td><?php echo $e['tanggalTransaksi'] ?></td>
                    <td class="d-flex justify-content-center">
                        <a class="btn btn-warning" href="index.php?pages=listTransaksi&type=transaksi&action=edit&id=<?php echo $e['id'] ?>">Edit</a>
                        <a class="btn btn-danger mx-3" href="default.php?menu=delete&type=transaksi&id=<?php echo $e['id'] ?>">Delete</a>
                    </td>
                </tr>
            <?php } ?>
        </table>
        <?php
        if ($action == "edit") {
            include "components/editTransaksi.php";
        }
        ?>
    </div>
</div>
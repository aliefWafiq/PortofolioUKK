<?php
$id = isset($_GET['id']) ? $_GET['id'] : "";

$sql = "SELECT * FROM user WHERE id = '$id'";
$res = $proses->show_data($sql);
?>
<form action="default.php?menu=editUser&id=<?php echo $res['id'] ?>" method="POST" class="card col-3 mx-3">
    <div class="card-body">
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" name="username" placeholder="Username" value="<?php echo $res['username'] ?>">
        </div>
        <label for="role" class="form-label">Role</label>
        <select name="role" id="role" class="form-select">
            <option value="<?php echo $res['username'] ?>"><?php echo $res['username'] ?></option>
            <option value="Admin">Admin</option>
            <option value="Petugas">Petugas</option>
        </select>
        <button type="submit" class="btn btn-primary mt-3">Submit</button>
    </div>
</form>
<?php
$id = isset($_GET['id']) ? $_GET['id'] : "";

$sql = "SELECT * FROM barang WHERE id = '$id'";
$res = $proses->show_data($sql);
?>
<form action="default.php?menu=edit&id=<?php echo $res['id'] ?>" method="POST" class="card col-3 mx-3">
    <div class="card-body">
        <div class="mb-3">
            <label for="namaBarang" class="form-label">Nama Barang</label>
            <input type="text" class="form-control" id="namaBarang" name="namaBarang" placeholder="Nama Barang" value="<?php echo $res['namaBarang'] ?>">
        </div>
        <div class="mb-3">
            <label for="hargaBarang" class="form-label">Harga Barang</label>
            <input type="number" class="form-control" id="hargaBarang" name="hargaBarang" placeholder="Harga Barang" value="<?php echo $res['hargaBarang'] ?>">
        </div>
        <div class="mb-3">
            <label for="stokBarang" class="form-label">Stok Barang</label>
            <input type="number" class="form-control" id="stokBarang" name="stokBarang" placeholder="Stok Barang" value="<?php echo $res['stokBarang'] ?>">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</form>
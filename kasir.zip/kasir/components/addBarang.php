<form action="default.php?menu=add" method="POST" class="card col-3 mx-3">
    <div class="card-body">
        <div class="mb-3">
            <label for="namaBarang" class="form-label">Nama Barang</label>
            <input type="text" class="form-control" id="namaBarang" name="namaBarang" placeholder="Nama Barang">
        </div>
        <div class="mb-3">
            <label for="hargaBarang" class="form-label">Harga Barang</label>
            <input type="number" class="form-control" id="hargaBarang" name="hargaBarang" placeholder="Harga Barang">
        </div>
        <div class="mb-3">
            <label for="stokBarang" class="form-label">Stok Barang</label>
            <input type="number" class="form-control" id="stokBarang" name="stokBarang" placeholder="Stok Barang">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</form>
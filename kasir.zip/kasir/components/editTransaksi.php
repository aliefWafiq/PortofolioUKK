<?php
$id = isset($_GET['id']) ? $_GET['id'] : "";

$sql = "SELECT * FROM transaksi WHERE id = '$id'";
$res = $proses->show_data($sql);
?>
<form action="default.php?menu=editTransaksi&id=<?php echo $res['id'] ?>" method="POST" class="card col-3 mx-3">
    <div class="card-body">
        <div class="mb-3">
            <label for="totalHarga" class="form-label">Total Harga</label>
            <input type="number" class="form-control" id="totalHarga" name="totalHarga" placeholder="Total Harga" value="<?php echo $res['totalHarga'] ?>">
        </div>
        <div class="mb-3">
            <label for="tanggalTransaksi" class="form-label">Tanggal Transaksi</label>
            <input type="date" name="tanggalTransaksi" value="<?php echo $res['tanggalTransaksi'] ?>">
        </div>
        <button type="submit" class="btn btn-primary mt-3">Submit</button>
    </div>
</form>